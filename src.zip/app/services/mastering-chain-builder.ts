/**
 * MASTERING CHAIN BUILDER
 * ========================
 * 
 * Shared chain builder that works with BOTH AudioContext (real-time playback)
 * and OfflineAudioContext (offline export).
 * 
 * CRITICAL RULES:
 * - Same topology in draft and export (only quality parameters change)
 * - No graph rebuild on slider move (only parameter ramps)
 * - Quality mode only changes: oversampling, lookahead, metering resolution
 * - One truth source: Preset → BaseProfile → UserOffsets → EffectiveProfile → DSP
 * 
 * QUALITY MODES:
 * - draft: 1-2x oversampling, short-term LUFS, minimal lookahead
 * - export: 4x oversampling, integrated LUFS, full lookahead
 */

import type { ProcessingPlan } from '../data/preset-resolution';
import type { ProcessingSettings } from './audio-processor';
import type { QualityMode } from '../data/quality-profiles';
import { buildTransformerStage, getTransformerConfig } from './stages/transformer-stage';
import { buildTapeStage, getTapeConfig } from './stages/tape-stage';
import { smoothParam } from './stages/stage-utils';

export interface MasteringChainConfig {
  context: BaseAudioContext;
  destination: AudioNode;
  params: ProcessingPlan;
  settings: ProcessingSettings;
  quality: QualityMode;
  useMinimalMaster: boolean;
}

export interface MasteringChain {
  input: AudioNode;
  output: AudioNode;
  parameters: ChainParameters;
  dispose: () => void;
}

export interface ChainParameters {
  // Transformer
  transformerDrive: AudioParam | null;
  
  // Tape
  tapeDrive: AudioParam | null;
  
  // EQ (User-adjustable profile EQ)
  lowShelfGain: AudioParam | null;
  midRangeGain: AudioParam | null;
  highShelfGain: AudioParam | null;
  
  // Multiband (if active)
  multibandInput: AudioNode | null;
  
  // SSL Compression
  sslThreshold: AudioParam | null;
  sslRatio: AudioParam | null;
  sslAttack: AudioParam | null;
  sslRelease: AudioParam | null;
  
  // M/S Processing
  stereoWidth: AudioParam | null;
  
  // Limiter
  limiterThreshold: AudioParam | null;
  limiterMakeup: AudioParam | null;
  limiterCeiling: AudioParam | null;
}

/**
 * Build the complete 6-stage mastering chain
 * 
 * Chain order:
 * 1. Transformer (harmonic enhancement)
 * 2. Tape (saturation with hysteresis)
 * 3. Multiband (surgical frequency management)
 * 4. SSL Bus Glue (compression)
 * 5. M/S Processing (stereo width)
 * 6. Limiter (peak management + loudness targeting)
 */
export function buildMasteringChain(config: MasteringChainConfig): MasteringChain {
  const { context, destination, params, settings, quality, useMinimalMaster } = config;
  
  console.log(`🔧 Building mastering chain (quality: ${quality}, minimal: ${useMinimalMaster})`);
  
  // Create input/output nodes
  const chainInput = context.createGain();
  chainInput.channelCountMode = 'max';
  chainInput.channelInterpretation = 'speakers';
  
  const chainOutput = context.createGain();
  chainOutput.channelCountMode = 'max';
  chainOutput.channelInterpretation = 'speakers';
  
  // Track current node in chain
  let currentNode: AudioNode = chainInput;
  
  // Track parameters for live updates
  const parameters: ChainParameters = {
    transformerDrive: null,
    tapeDrive: null,
    lowShelfGain: null,
    midRangeGain: null,
    highShelfGain: null,
    multibandInput: null,
    sslThreshold: null,
    sslRatio: null,
    sslAttack: null,
    sslRelease: null,
    stereoWidth: null,
    limiterThreshold: null,
    limiterMakeup: null,
    limiterCeiling: null,
  };
  
  // Track nodes for cleanup
  const nodesToDispose: AudioNode[] = [chainInput, chainOutput];
  
  // Quality-dependent settings
  const oversamplingFactor = quality === 'draft' ? 1 : 4;
  const enableHeavyProcessing = quality === 'export';
  
  console.log(`   Oversampling: ${oversamplingFactor}x`);
  console.log(`   Heavy processing: ${enableHeavyProcessing ? 'enabled' : 'disabled'}`);
  
  // === PROFILE EQ (User-Adjustable 3-Band) ===
  console.log('   [0] Profile EQ: ACTIVE (Low/Mid/High shelves)');
  const profileEQ = createProfileEQ(context, params);
  currentNode.connect(profileEQ.input);
  currentNode = profileEQ.output;
  parameters.lowShelfGain = profileEQ.lowShelfGain;
  parameters.midRangeGain = profileEQ.midRangeGain;
  parameters.highShelfGain = profileEQ.highShelfGain;
  nodesToDispose.push(profileEQ.input, profileEQ.output);
  
  // === STAGE 1: TRANSFORMER (Harmonic Enhancement) ===
  if (!useMinimalMaster && params.genreBehavior.colorAmount > 0) {
    console.log('   [1] Transformer: ACTIVE');
    const transformerConfig = getTransformerConfig(settings.genreId);
    const transformer = buildTransformerStage(context, quality, transformerConfig);
    currentNode.connect(transformer.input);
    currentNode = transformer.output;
    parameters.transformerDrive = transformer.params.drive;
    nodesToDispose.push(transformer.input, transformer.output);
  } else {
    console.log('   [1] Transformer: BYPASSED');
  }
  
  // === STAGE 2: TAPE SATURATION ===
  if (!useMinimalMaster && params.genreBehavior.colorAmount > 0) {
    console.log('   [2] Tape: ACTIVE');
    const tapeConfig = getTapeConfig(settings.genreId, settings.circuitDrive);
    const tape = buildTapeStage(context, quality, tapeConfig);
    currentNode.connect(tape.input);
    currentNode = tape.output;
    parameters.tapeDrive = tape.params.drive;
    nodesToDispose.push(tape.input, tape.output);
  } else {
    console.log('   [2] Tape: BYPASSED');
  }
  
  // === STAGE 3: MULTIBAND PROCESSING ===
  const useMultiband = params.genreBehavior.useMultiband && !useMinimalMaster && enableHeavyProcessing;
  if (useMultiband) {
    console.log('   [3] Multiband: ACTIVE (4-band split)');
    const multiband = createMultibandStage(context, settings, quality);
    currentNode.connect(multiband.input);
    currentNode = multiband.output;
    parameters.multibandInput = multiband.input;
    nodesToDispose.push(multiband.input, multiband.output);
  } else {
    console.log('   [3] Multiband: BYPASSED');
  }
  
  // === STAGE 4: SSL BUS GLUE COMPRESSION ===
  console.log('   [4] SSL Compression: ACTIVE');
  const ssl = createSSLCompressor(context, settings, quality, useMinimalMaster);
  currentNode.connect(ssl.input);
  currentNode = ssl.output;
  parameters.sslThreshold = ssl.threshold;
  parameters.sslRatio = ssl.ratio;
  parameters.sslAttack = ssl.attack;
  parameters.sslRelease = ssl.release;
  nodesToDispose.push(ssl.input, ssl.output);
  
  // === STAGE 5: MID-SIDE PROCESSING ===
  const useMidSide = params.genreBehavior.useMidSide;
  if (useMidSide) {
    console.log('   [5] M/S Processing: ACTIVE');
    const midSide = createMidSideProcessor(context, settings, params);
    currentNode.connect(midSide.input);
    currentNode = midSide.output;
    parameters.stereoWidth = midSide.widthParam;
    nodesToDispose.push(midSide.input, midSide.output);
  } else {
    console.log('   [5] M/S Processing: BYPASSED');
  }
  
  // === STAGE 6: LIMITER (Peak Management + Loudness Targeting) ===
  console.log('   [6] Limiter: ACTIVE');
  const limiter = createLimiterStage(context, settings, quality);
  currentNode.connect(limiter.input);
  currentNode = limiter.output;
  parameters.limiterThreshold = limiter.threshold;
  parameters.limiterMakeup = limiter.makeup;
  parameters.limiterCeiling = limiter.ceiling;
  nodesToDispose.push(limiter.input, limiter.output);
  
  // Connect final output to destination
  currentNode.connect(chainOutput);
  chainOutput.connect(destination);
  
  console.log(`✅ Mastering chain built: ${nodesToDispose.length / 2} stages`);
  
  return {
    input: chainInput,
    output: chainOutput,
    parameters,
    dispose: () => {
      // Disconnect all nodes
      nodesToDispose.forEach(node => {
        try {
          node.disconnect();
        } catch (e) {
          // Ignore disconnection errors
        }
      });
    }
  };
}

/**
 * STAGE 3: Multiband Processing (Surgical Frequency Management)
 * SIMPLIFIED PLACEHOLDER - Multiband is complex and will need the existing implementation
 */
function createMultibandStage(
  context: BaseAudioContext,
  settings: ProcessingSettings,
  quality: QualityMode
): { input: AudioNode; output: AudioNode } {
  // TODO: Port the full multiband implementation from audio-processor.ts
  // For now, return a passthrough
  const input = context.createGain();
  const output = context.createGain();
  input.connect(output);
  
  console.warn('   ⚠️  Multiband stage is a passthrough (TODO: port full implementation)');
  
  return { input, output };
}

/**
 * STAGE 4: SSL Bus Glue Compression
 */
function createSSLCompressor(
  context: BaseAudioContext,
  settings: ProcessingSettings,
  quality: QualityMode,
  useMinimalMaster: boolean
): {
  input: AudioNode;
  output: AudioNode;
  threshold: AudioParam;
  ratio: AudioParam;
  attack: AudioParam;
  release: AudioParam;
} {
  const input = context.createGain();
  const output = context.createGain();
  
  const compressor = context.createDynamicsCompressor();
  
  // SSL 9000K settings
  if (useMinimalMaster) {
    // Minimal mode: gentle compression (max 1.5dB GR)
    compressor.threshold.value = -18; // Higher threshold = less compression
    compressor.ratio.value = 2;
    compressor.attack.value = 0.003;
    compressor.release.value = 0.1;
  } else {
    // Full mode: standard SSL bus glue
    compressor.threshold.value = -8;
    compressor.ratio.value = 2.5;
    compressor.attack.value = 0.001; // Fast attack (<1ms)
    compressor.release.value = 0.08; // 80ms base release (Auto mode will adjust)
  }
  
  compressor.knee.value = quality === 'draft' ? 0 : 6; // Soft knee in export mode
  
  // Unity gain output (no makeup gain in SSL stage)
  output.gain.value = 1.0;
  
  input.connect(compressor);
  compressor.connect(output);
  
  return {
    input,
    output,
    threshold: compressor.threshold,
    ratio: compressor.ratio,
    attack: compressor.attack,
    release: compressor.release,
  };
}

/**
 * STAGE 5: Mid-Side Processing
 */
function createMidSideProcessor(
  context: BaseAudioContext,
  settings: ProcessingSettings,
  params: ProcessingPlan
): { input: AudioNode; output: AudioNode; widthParam: AudioParam } {
  const input = context.createGain();
  const output = context.createGain();
  
  // Split stereo to L/R
  const splitter = context.createChannelSplitter(2);
  
  // Encode to Mid-Side
  // Mid = (L + R) / 2
  // Side = (L - R) / 2
  const midGain = context.createGain();
  midGain.gain.value = 0.5;
  
  const sideGain = context.createGain();
  sideGain.gain.value = 0.5;
  
  const sideInverter = context.createGain();
  sideInverter.gain.value = -1;
  
  // L + R = Mid
  input.connect(splitter);
  splitter.connect(midGain, 0);
  splitter.connect(midGain, 1);
  
  // L - R = Side
  splitter.connect(sideGain, 0);
  splitter.connect(sideInverter, 1);
  sideInverter.connect(sideGain);
  
  // Width control on Side channel
  const widthControl = context.createGain();
  
  // Get width from params
  const requestedWidth = params.source.requestedWidth ?? 1.0;
  const widthAmount = Math.max(0, Math.min(2.0, requestedWidth));
  widthControl.gain.value = widthAmount;
  
  sideGain.connect(widthControl);
  
  // Decode back to L/R
  // L = Mid + Side
  // R = Mid - Side
  const leftChannel = context.createGain();
  const rightChannel = context.createGain();
  
  midGain.connect(leftChannel);
  widthControl.connect(leftChannel);
  
  const sideInverter2 = context.createGain();
  sideInverter2.gain.value = -1;
  
  midGain.connect(rightChannel);
  widthControl.connect(sideInverter2);
  sideInverter2.connect(rightChannel);
  
  // Merge back to stereo
  const merger = context.createChannelMerger(2);
  leftChannel.connect(merger, 0, 0);
  rightChannel.connect(merger, 0, 1);
  
  merger.connect(output);
  
  return { input, output, widthParam: widthControl.gain };
}

/**
 * STAGE 6: Limiter (Weiss DS1-MK3 style)
 * SIMPLIFIED PLACEHOLDER - Limiter needs the multi-stage limiter implementation
 */
function createLimiterStage(
  context: BaseAudioContext,
  settings: ProcessingSettings,
  quality: QualityMode
): {
  input: AudioNode;
  output: AudioNode;
  threshold: AudioParam;
  makeup: AudioParam;
  ceiling: AudioParam;
} {
  const input = context.createGain();
  const output = context.createGain();
  
  // Calculate makeup gain (SOLE loudness authority)
  const currentLUFS = -16; // TODO: Get from analysis
  const targetLUFS = settings.targetLUFS ?? -14;
  const requiredGainDB = targetLUFS - currentLUFS;
  const makeupGainDB = Math.max(-10, Math.min(requiredGainDB, 20));
  const makeupGainLinear = Math.pow(10, makeupGainDB / 20);
  
  // Apply makeup gain
  const makeupGain = context.createGain();
  makeupGain.gain.value = makeupGainLinear;
  
  // Simple limiter (DynamicsCompressor with hard ratio)
  const limiter = context.createDynamicsCompressor();
  limiter.threshold.value = -1.0; // 1dB below 0dBFS
  limiter.ratio.value = 20; // Hard limiting
  limiter.attack.value = 0.001; // 1ms
  limiter.release.value = settings.logicMode === 'brickwall' ? 0.05 : 0.1;
  limiter.knee.value = 0; // Hard knee
  
  // Soft clipper (safety ceiling)
  const softClipper = context.createWaveShaper();
  const curve = new Float32Array(65536);
  const ceilingLinear = Math.pow(10, -0.1 / 20); // -0.1 dBTP
  
  for (let i = 0; i < 65536; i++) {
    const x = (i * 2 - 65536) / 65536;
    const scaled = x / ceilingLinear;
    curve[i] = Math.tanh(scaled) * ceilingLinear * 0.98; // Safety margin
  }
  
  softClipper.curve = curve;
  softClipper.oversample = quality === 'draft' ? 'none' : '4x';
  
  // Chain
  input.connect(makeupGain);
  makeupGain.connect(limiter);
  limiter.connect(softClipper);
  softClipper.connect(output);
  
  return {
    input,
    output,
    threshold: limiter.threshold,
    makeup: makeupGain.gain,
    ceiling: limiter.threshold, // Proxy for ceiling
  };
}

/**
 * PROFILE EQ (User-Adjustable 3-Band)
 */
function createProfileEQ(
  context: BaseAudioContext,
  params: ProcessingPlan
): {
  input: AudioNode;
  output: AudioNode;
  lowShelfGain: AudioParam;
  midRangeGain: AudioParam;
  highShelfGain: AudioParam;
} {
  const input = context.createGain();
  const output = context.createGain();
  
  // Low shelf
  const lowShelf = context.createBiquadFilter();
  lowShelf.type = 'lowshelf';
  lowShelf.frequency.value = 100; // 100Hz
  lowShelf.gain.value = params.source.lowShelfGain ?? 0;
  
  // Mid range
  const midRange = context.createBiquadFilter();
  midRange.type = 'peaking';
  midRange.frequency.value = 1000; // 1kHz
  midRange.Q.value = 1.414; // 1 octave bandwidth
  midRange.gain.value = params.source.midRangeGain ?? 0;
  
  // High shelf
  const highShelf = context.createBiquadFilter();
  highShelf.type = 'highshelf';
  highShelf.frequency.value = 10000; // 10kHz
  highShelf.gain.value = params.source.highShelfGain ?? 0;
  
  // Chain
  input.connect(lowShelf);
  lowShelf.connect(midRange);
  midRange.connect(highShelf);
  highShelf.connect(output);
  
  return {
    input,
    output,
    lowShelfGain: lowShelf.gain,
    midRangeGain: midRange.gain,
    highShelfGain: highShelf.gain,
  };
}